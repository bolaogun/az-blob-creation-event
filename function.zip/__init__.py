import azure.functions as func
import json
import logging
import os
from typing import Dict, Any


def main(event: func.EventGridEvent) -> None:
    """
    Azure Function to handle Azure Storage BlobCreated events.
    
    This function processes blob creation events from Azure Event Grid
    and logs the event details for further processing.
    """
    
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    try:
        # Extract event data
        event_data = event.get_json()
        subject = event.subject
        event_type = event.event_type
        event_time = event.event_time
        
        logger.info(f"Processing event: {event_type}")
        logger.info(f"Event subject: {subject}")
        logger.info(f"Event time: {event_time}")
        
        # Extract blob information
        blob_url = event_data.get('url', '')
        blob_name = subject.split('/blobs/')[-1] if '/blobs/' in subject else 'unknown'
        container_name = subject.split('/containers/')[-1].split('/blobs/')[0] if '/containers/' in subject else 'unknown'
        
        # Log blob details
        logger.info(f"Blob created: {blob_name}")
        logger.info(f"Container: {container_name}")
        logger.info(f"Blob URL: {blob_url}")
        
        # Process the blob creation event
        process_blob_event(event_data, blob_name, container_name, blob_url)
        
        logger.info("Event processed successfully")
        
    except Exception as e:
        logger.error(f"Error processing event: {str(e)}")
        raise


def process_blob_event(event_data: Dict[str, Any], blob_name: str, container_name: str, blob_url: str) -> None:
    """
    Process the blob creation event.
    
    Args:
        event_data: The event data from Event Grid
        blob_name: Name of the created blob
        container_name: Name of the container
        blob_url: URL of the created blob
    """
    
    logger = logging.getLogger(__name__)
    
    # Extract additional event properties
    api = event_data.get('api', 'unknown')
    content_type = event_data.get('contentType', 'unknown')
    content_length = event_data.get('contentLength', 0)
    blob_type = event_data.get('blobType', 'unknown')
    
    logger.info(f"API operation: {api}")
    logger.info(f"Content type: {content_type}")
    logger.info(f"Content length: {content_length} bytes")
    logger.info(f"Blob type: {blob_type}")
    
    # Add your custom blob processing logic here
    # For example:
    # - Validate blob format
    # - Extract metadata
    # - Trigger downstream processing
    # - Send notifications
    # - Update database records
    
    # Example: Process based on blob type
    if blob_name.endswith('.json'):
        logger.info("Processing JSON blob")
        # Add JSON-specific processing logic
    elif blob_name.endswith('.csv'):
        logger.info("Processing CSV blob")
        # Add CSV-specific processing logic
    elif blob_name.endswith(('.jpg', '.jpeg', '.png')):
        logger.info("Processing image blob")
        # Add image-specific processing logic
    else:
        logger.info("Processing generic blob")
        # Add generic processing logic
    
    logger.info(f"Blob {blob_name} processed successfully")